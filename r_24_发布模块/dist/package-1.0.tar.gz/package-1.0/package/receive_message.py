def receive():
    return "这是来自666的消息"